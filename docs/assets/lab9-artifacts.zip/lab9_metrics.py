"""Compute first-delivery sprint metrics from actual stage-event history.
Input CSV: card_id,timestamp,status. Times: ISO8601 with UTC offset.
No synthetic events are generated. Include full history before sprint start.
Usage: python lab9_metrics.py events.csv 2026-11-02 2026-11-06 sprint1
"""
import csv, sys, json, math
from datetime import datetime, timedelta, timezone
from pathlib import Path
from collections import defaultdict
STAGES=['Backlog','Ready','In progress','Review','Testing','Done']
TZ=timezone(timedelta(hours=5))
def parse(t):
 d=datetime.fromisoformat(t.replace('Z','+00:00'))
 if d.tzinfo is None:raise ValueError('timestamp must include offset')
 return d
def analyze(path,start,end):
 begin=datetime.fromisoformat(start).replace(tzinfo=TZ)
 finish=datetime.fromisoformat(end).replace(tzinfo=TZ)+timedelta(days=1)
 if finish<=begin:raise ValueError('invalid interval')
 history=defaultdict(list)
 with open(path,encoding='utf-8-sig',newline='') as f:
  for row in csv.DictReader(f):
   if not row.get('card_id') or not row.get('timestamp') or row.get('status') not in STAGES:raise ValueError('incomplete row or unsupported status')
   history[row['card_id']].append((parse(row['timestamp']),row['status']))
 if not history:raise ValueError('No actual event history; empty data is not zero throughput')
 ct=[];done_ids=[];aging={}
 for card,events in history.items():
  events.sort()
  starts=[t for t,s in events if s=='In progress'];dones=[t for t,s in events if s=='Done']
  first_done=min(dones) if dones else None
  if first_done and begin<=first_done<finish:
   valid_starts=[t for t in starts if t<=first_done]
   if not valid_starts:raise ValueError(f'{card}: missing start before Done')
   done_ids.append(card);ct.append((first_done-min(valid_starts)).total_seconds()/86400)
  before=[(t,s) for t,s in events if t<finish]
  if before and before[-1][1]!='Done':
   known=[t for t in starts if t<finish]
   if known:aging[card]=(finish-min(known)).total_seconds()/86400
 days=[];counts=[]
 day=begin
 while day<finish:
  cutoff=day+timedelta(days=1);row={s:0 for s in STAGES}
  for events in history.values():
   known=[(t,s) for t,s in events if t<cutoff]
   if known:row[known[-1][1]]+=1
  days.append(day.date().isoformat());counts.append(row);day=cutoff
 ordered=sorted(ct);p85=ordered[max(0,math.ceil(.85*len(ordered))-1)] if ordered else None
 return {'throughput':len(done_ids),'completed_cards':done_ids,'mean_cycle_days':sum(ct)/len(ct) if ct else None,'p85_cycle_days':p85,'aging_at_period_end_days':aging,'max_wip':max(sum(r[s] for s in ['In progress','Review','Testing']) for r in counts),'days':days,'counts':counts,'scope':'first delivery; calendar elapsed days; unknown history remains missing'}
if __name__=='__main__':
 if len(sys.argv)!=5:raise SystemExit('usage: events.csv YYYY-MM-DD YYYY-MM-DD tag')
 _,p,s,e,tag=sys.argv
 result=analyze(p,s,e)
 Path(tag+'_metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 # Exact daily state occupancy, with separate queues and active stages.
 order=['Done','Testing','Review','In progress','Ready','Backlog']
 fig,ax=plt.subplots(figsize=(10,5))
 ax.stackplot(result['days'],*[[r[k] for r in result['counts']] for k in order],labels=order)
 ax.set_ylabel('Cards');ax.set_title('Stage flow '+tag);ax.legend(loc='upper left');fig.autofmt_xdate()
 fig.tight_layout();fig.savefig(tag+'_cfd.png',dpi=160);plt.close(fig)
 print(json.dumps({k:v for k,v in result.items() if k not in ['counts','days']},ensure_ascii=False,indent=2))
