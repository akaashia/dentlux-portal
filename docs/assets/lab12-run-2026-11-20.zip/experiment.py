"""Run a new DentLux evaluation against a local llama-server."""

import argparse
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from urllib.parse import urlsplit
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
ROUTES = ["BOOK", "MOVE", "CANCEL", "INFO", "HUMAN"]
SCHEMA = {
    "type": "object",
    "properties": {"route": {"type": "string", "enum": ROUTES}},
    "required": ["route"],
    "additionalProperties": False,
}


def request(server, path, body=None):
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    headers = {"Content-Type": "application/json"}
    with urlopen(Request(server + path, data=data, headers=headers), timeout=40) as response:
        return json.load(response)


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def score(records, field):
    outcomes = [(record["gold"], record[field]) for record in records]
    human = [pred for gold, pred in outcomes if gold == "HUMAN"]
    f1_scores = []
    for label in ROUTES:
        correct = sum(gold == pred == label for gold, pred in outcomes)
        support = sum(gold == label for gold, _ in outcomes)
        predicted = sum(pred == label for _, pred in outcomes)
        f1_scores.append(2 * correct / (support + predicted) if support + predicted else 0)
    return {
        "examples": len(outcomes),
        "correct": sum(gold == pred for gold, pred in outcomes),
        "accuracy": sum(gold == pred for gold, pred in outcomes) / len(outcomes),
        "macro_f1": sum(f1_scores) / len(f1_scores),
        "human_recall": human.count("HUMAN") / len(human) if human else None,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--server", default="http://127.0.0.1:18112")
    parser.add_argument("--model-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    server = args.server.rstrip("/")
    parsed = urlsplit(server)
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        parser.error("Use the local llama-server address")
    base = ROOT / "gold-from-report.csv"
    baseline_path = ROOT / "predictions-from-report.csv"
    prompt_path = ROOT / "prompt-from-report.txt"
    with base.open(encoding="utf-8-sig", newline="") as file:
        examples = list(csv.DictReader(file))
    with baseline_path.open(encoding="utf-8-sig", newline="") as file:
        baseline = {row["id"]: row["rules"] for row in csv.DictReader(file)}
    assert len(examples) == len({row["id"] for row in examples}) == 40
    prompt = prompt_path.read_text(encoding="utf-8").strip()
    models = request(server, "/v1/models")
    model = models["data"][0]["id"]
    parameters = {
        "model": model,
        "temperature": 0,
        "seed": 42,
        "max_tokens": 40,
        "response_format": {
            "type": "json_schema",
            "json_schema": {"name": "dentlux_route", "strict": True, "schema": SCHEMA},
        },
    }
    args.output.mkdir(parents=True)
    started_at = datetime.now(timezone.utc).isoformat()
    metadata = {
        "started_at_utc": started_at,
        "input_source": "Synthetic examples and keyword baseline reconstructed from the lab report",
        "dataset_sha256": digest(base),
        "prompt_file_sha256": digest(prompt_path),
        "baseline_sha256": digest(baseline_path),
        "model_sha256": digest(args.model_file),
        "server_models": models,
        "parameters": parameters,
    }
    (args.output / "run-metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    records = []
    for example in examples:
        payload = {
            **parameters,
            "messages": [
                {"role": "system", "content": prompt},
                {"role": "user", "content": example["text"]},
            ],
        }
        start = perf_counter()
        response = request(server, "/v1/chat/completions", payload)
        elapsed = perf_counter() - start
        content = response["choices"][0]["message"]["content"]
        try:
            pred = json.loads(content).get("route")
        except (AttributeError, ValueError):
            pred = None
        usage = response["usage"]
        records.append({
            "id": example["id"],
            "split": example["split"],
            "gold": example["gold"],
            "rules": baseline[example["id"]],
            "prediction": pred if pred in ROUTES else None,
            "elapsed_seconds": elapsed,
            "prompt_tokens": usage["prompt_tokens"],
            "completion_tokens": usage["completion_tokens"],
            "response": response,
        })
        if len(records) % 10 == 0:
            print(f"Evaluated {len(records)}/{len(examples)} examples", flush=True)
    (args.output / "raw-results.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    latencies = sorted(record["elapsed_seconds"] for record in records)
    metrics = {
        split: {
            "qwen": score([record for record in records if record["split"] == split], "prediction"),
            "rules_from_report": score([record for record in records if record["split"] == split], "rules"),
        }
        for split in sorted({record["split"] for record in records})
    }
    metrics["p95_seconds"] = latencies[math.ceil(len(latencies) * 0.95) - 1]
    metrics["valid_json_routes"] = sum(record["prediction"] in ROUTES for record in records)
    (args.output / "metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
