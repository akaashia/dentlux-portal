# Повторный эксперимент DentLux №12

20 ноября 2026 года готовая Qwen2.5-0.5B-Instruct Q4_K_M обработала 40 синтетических обращений. Тексты, эталоны, промпт и предсказания базовых правил восстановлены из таблиц отчёта. SHA-256 фактических входов и модели записаны в `run-metadata.json`.

`raw-results.json` содержит полный ответ локального сервера, задержку, входные и выходные токены для каждого обращения. Сводка по двум выборкам находится в `metrics.json`.

## Повторный запуск

1. Скачайте [модель Qwen Q4_K_M](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/tree/9217f5db79a29953eb74d5343926648285ec7e67) и [Windows-сборку llama.cpp b12532](https://github.com/ggml-org/llama.cpp/releases/tag/b12532). Хэш файла модели указан в метаданных.
2. Распакуйте файлы llama.cpp вместе с этим архивом и поместите модель рядом. Запустите локальный сервер и скрипт с Python 3.11 или новее.

```powershell
.\llama-server.exe -m .\qwen2.5-0.5b-instruct-q4_k_m.gguf --alias dentlux-qwen2.5-0.5b-q4km --host 127.0.0.1 --port 18112 -c 2048 -t 4 --parallel 1 -ngl 0
python experiment.py --model-file .\qwen2.5-0.5b-instruct-q4_k_m.gguf --output new-run
```

Запускайте вторую команду в другом окне после загрузки модели. Для каждой сессии используйте новую папку результатов.
