from anonymize import minimize
def fixture():
 return [{'patient_id':'fictional-42','name':'FAKE Original A','phone':'+77001234567','date':'2026-01-10','doctorId':'aida','time':'10:00','iin':'FICTIONAL-IIN','notes':'FAKE secret','email':'fake@example.invalid'},
 {'patient_id':'fictional-42','name':'FAKE Original A','phone':'+77001234567','date':'2026-01-11','doctorId':'aida','time':'11:00','address':'FAKE address'}]
def test_removes_original_identifiers_and_free_text():
 result=minimize(fixture());s=str(result)
 for token in ['fictional-42','FAKE','+77001234567','2026-01-10','iin','email','notes','address']:assert token not in s
def test_preserves_repeat_identity_without_original_key():
 rows=minimize(fixture());assert rows[0]['patient_token']==rows[1]['patient_token'];assert rows[0]['name']==rows[1]['name']
def test_dates_are_rebased_and_only_allowed_columns_survive():
 rows=minimize(fixture());assert rows[0]['date']=='2030-01-07';assert rows[1]['date']=='2030-01-08'
 assert set(rows[0])=={'patient_token','name','phone','date','doctorId','time','synthetic'}
def test_rejects_missing_identity():
 import pytest
 with pytest.raises(ValueError):minimize([{'date':'2026-01-01','doctorId':'aida','time':'10:00'}])
