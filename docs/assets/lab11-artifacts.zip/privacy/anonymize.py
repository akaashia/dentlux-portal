"""Minimize CSV data for a disconnected synthetic test environment.
Output is NOT safe to send to a real SMS gateway. Original dates, identifiers,
notes, email, address and IIN are discarded. No mapping is saved.
Usage: python anonymize.py source.csv minimized.csv
"""
import csv,sys
from datetime import date,timedelta
def minimize(rows):
    tokens={};days={};out=[]
    for r in rows:
        identity=r.get('patient_id') or r.get('phone') or r.get('name')
        if not identity:raise ValueError('missing patient identity')
        if identity not in tokens:tokens[identity]=len(tokens)+1
        if r['date'] not in days:days[r['date']]=len(days)
        n=tokens[identity]
        out.append({'patient_token':f'TEST-{n:04d}','name':f'Synthetic Patient {n:04d}',
          'phone':f'+7000000{n:04d}', 'date':str(date(2030,1,7)+timedelta(days=days[r['date']])),
          'doctorId':r['doctorId'],'time':r['time'],'synthetic':'true'})
    return out
if __name__=='__main__':
    with open(sys.argv[1],encoding='utf-8-sig',newline='') as f:rows=minimize(list(csv.DictReader(f)))
    if not rows:raise SystemExit('empty input')
    with open(sys.argv[2],'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
