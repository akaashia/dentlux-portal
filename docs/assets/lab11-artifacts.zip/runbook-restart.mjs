import {spawn} from 'node:child_process';
import {mkdirSync,openSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {localDate,addDays} from './backend/booking.mjs';
const evidence=path.resolve('../outputs/lab11/Дополнения/evidence');
const privateDir=path.resolve('../.work/lab11/demo-data');mkdirSync(privateDir,{recursive:true});
const base='http://127.0.0.1:3111';
const log=openSync(path.join(privateDir,'server.log'),'a');
const env={...process.env,NODE_ENV:'test',DEMO_MODE:'true',HOST:'127.0.0.1',PORT:'3111',DATA_DIR:privateDir,
 DATABASE_URL:'',DATA_ENCRYPTION_KEY:'',SQLITE_PATH:path.join(privateDir,'lab11.sqlite'),APP_ORIGIN:base,PUBLIC_URL:base,
 SMS_GATEWAY_URL:'',SMS_GATEWAY_TOKEN:'',TELEGRAM_BOT_TOKEN:'',METRICS_TOKEN:''};
async function start(){
 const p=spawn(process.execPath,['backend/server.mjs'],{cwd:process.cwd(),env,detached:true,windowsHide:true,stdio:['ignore',log,log]});p.unref();
 for(let i=0;i<100;i++){
  try{const r=await fetch(base+'/api/health');if(r.ok)return p;}catch{}
  await new Promise(r=>setTimeout(r,150));
 }
 throw new Error('demo server did not start');
}
try{await fetch(base+'/api/health');throw new Error('port 3111 is already occupied');}catch(e){if(e.message.includes('occupied'))throw e;}
let proc=await start();
let date=addDays(localDate(),1);if(new Date(date+'T12:00:00+05:00').getUTCDay()===0)date=addDays(date,1);
const body={doctorId:'aida',serviceId:'consultation',date,time:'10:00',name:'Synthetic Lab11 Patient',phone:'+70000000001',consent:true,notify:false};
const booking=await fetch(base+'/api/bookings',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify(body)});
if(booking.status!==201)throw new Error('seed booking failed '+await booking.text());
const saved=await booking.json();
const before=await fetch(base+'/');const root={status:before.status,contentType:before.headers.get('content-type')};
const panel=await fetch(base+'/api/panel/bookings?date='+date);const list=await panel.json();
const stopped=new Date();process.kill(proc.pid);
await new Promise(r=>setTimeout(r,400));
proc=await start();const recovered=new Date();
const restored=await fetch(base+'/api/bookings/'+saved.id);const after=await restored.json();
if(after.id!==saved.id||after.reference!==saved.reference)throw new Error('booking not preserved');
const evidenceData={timeUtc:new Date().toISOString(),environment:'local isolated demo SQLite synthetic only',baseUrl:base,
 root,anonymousPanel:{status:panel.status,returnsPatientFields:list.bookings.some(b=>'phone'in b&&'name'in b),productionGate:'Blocked until authenticated role access exists'},
 bookingDate:date,syntheticBookingReference:saved.reference,stoppedAt:stopped.toISOString(),recoveredAt:recovered.toISOString(),
 recoverySeconds:(recovered-stopped)/1000,bookingPreserved:after.id===saved.id,demoPid:proc.pid,mode:'actual controlled restart; not a production RTO measurement'};
writeFileSync(path.join(evidence,'runbook-restart.json'),JSON.stringify(evidenceData,null,2));
console.log(JSON.stringify(evidenceData,null,2));
