import http from 'k6/http';
import { check,sleep } from 'k6';
export const options={scenarios:{visitors:{executor:'constant-vus',vus:Number(__ENV.VUS||10),duration:__ENV.DURATION||'30s'}},
 thresholds:{'http_req_duration{endpoint:slots}':['p(95)<800'],'http_req_failed':['rate<0.01'],'checks':['rate>0.99']}};
export default function(){
 const base=__ENV.BASE_URL||'http://host.docker.internal:3111';
 let date=__ENV.BOOKING_DATE;if(!date)throw new Error('Set BOOKING_DATE to a working day within 60 days');
 let c=http.get(base+'/api/catalog',{tags:{endpoint:'catalog'}});check(c,{'catalog 200':r=>r.status===200});
 let s=http.get(base+'/api/slots?doctorId=aida&date='+date,{tags:{endpoint:'slots'}});check(s,{'slots 200':r=>r.status===200});sleep(1);
}
export function handleSummary(data){return {'/results/summary.json':JSON.stringify(data,null,2)};}
