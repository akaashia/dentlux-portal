# Lab 11 артефакттары

## Доска и трекер
Откройте tracker/index.html в браузере. Измените статус и используйте JSON экспорт. Это локальный трекер; GitHub Issues не менялся.

## Privacy
Из каталога Дополнения: `python -m pip install -r requirements.txt`, затем `python -m pytest privacy/test_anonymize.py -q`. Демонстрация: `python privacy/anonymize.py privacy/synthetic-source.csv privacy/minimized.csv`. Данные вымышленные. Даты 2030 предназначены только для демонстрации минимизации, не для импорта в текущий booking API. Любая SMS-интеграция в тестах должна быть отключена.

## Uptime Kuma
`docker compose -p dentlux-lab11 -f monitoring/compose.yaml up -d`. Открыть http://127.0.0.1:33011. На этом ноутбуке уже созданы два монитора на http://host.docker.internal:3111/ и /api/health, interval 20 секунд, timeout 5 секунд, retry 1. В новом окружении создайте admin и эти мониторы. Уведомления внешним людям не настроены. Пароль текущего локального admin хранится отдельно, не в этом архиве.

## k6
Из папки Дополнения в PowerShell:
```powershell
$labScripts=(Resolve-Path ./load).Path
$labResults=(Resolve-Path ./evidence).Path
docker run --rm --mount "type=bind,source=$labScripts,target=/scripts,readonly" --mount "type=bind,source=$labResults,target=/results" -e BOOKING_DATE=2026-11-11 -e VUS=10 -e DURATION=30s grafana/k6:1.6.0 run /scripts/slots.js
```
Выберите актуальный рабочий день внутри 60 дней. Результат summary.json перезапишется; сохраните исходную evidence перед повтором. Профиль фактического теста 10 VU 30 секунд; 200 VU 15 минут и двухчасовой тест требуют отдельного согласованного контура и выполнения. Все запросы read-only, никаких внешних SMS.

## Bruno
Открыть папку api как коллекцию, выбрать Local. Три запроса: health 200, catalog 200, некорректная дата 400. CLI не выполнялся. Это дополнительная коллекция к реально пройденным Node API тестам.

## Runbook
Скопировать runbook-restart.mjs в корень видимой изолированной копии проекта рядом с backend. Установить зависимости и собрать frontend. В текущем окружении скрипт ожидает соседнюю папку outputs/lab11/Дополнения/evidence и свободный порт 3111. Он намеренно не останавливает занятый порт. Пример выполнен в lab11-validation; этот snapshot сохранён отдельно на ноутбуке. Запуск создаёт только synthetic booking, перезапускает только собственный child process и проверяет id/reference. Учётные ключи и SQLite остаются в приватном .work/lab11/demo-data и не входят в архив.

## UAT
uat-scenarios.csv содержит все 12 сценариев. Результаты внутренних тестов не равны приёмке другой команды. Внешняя сессия не проведена и подписи не проставлены. Для production открыта DEF-01 по авторизации панели.
