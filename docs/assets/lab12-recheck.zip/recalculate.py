from pathlib import Path
import csv
import json

root = Path(__file__).resolve().parent
labels = ('BOOK', 'MOVE', 'CANCEL', 'INFO', 'HUMAN')


def read_csv(name):
    with (root / name).open(encoding='utf-8', newline='') as handle:
        return list(csv.DictReader(handle))


def evaluate(rows, predictions, key):
    pairs = [(row['gold'], predictions[row['id']][key]) for row in rows]
    assert all(expected in labels and prediction in labels for expected, prediction in pairs)
    scores = {}
    recalls = {}
    for label in labels:
        tp = sum(x == label and y == label for x, y in pairs)
        fp = sum(x != label and y == label for x, y in pairs)
        fn = sum(x == label and y != label for x, y in pairs)
        scores[label] = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0
        recalls[label] = tp / (tp + fn) if tp + fn else 0
    correct = sum(expected == prediction for expected, prediction in pairs)
    return {
        'examples': len(pairs),
        'correct': correct,
        'accuracy': round(correct / len(pairs), 4),
        'macro_f1': round(sum(scores.values()) / len(labels), 3),
        'human_recall': round(recalls['HUMAN'], 3),
    }


gold = read_csv('gold-from-report.csv')
predicted = read_csv('predictions-from-report.csv')
by_id = {row['id']: row for row in predicted}
assert len(gold) == len(predicted) == len(by_id) == 40
assert {row['id'] for row in gold} == set(by_id)
result = {}
for split in ('eval', 'holdout'):
    rows = [row for row in gold if row['split'] == split]
    result[split] = {key: evaluate(rows, by_id, key) for key in ('qwen', 'rules')}
costs = json.loads((root / 'cost-inputs-from-report.json').read_text(encoding='utf-8'))
budget = sum(
    costs['tokens_per_request'][kind] * costs['price_per_million_tokens'][kind]
    for kind in ('input', 'output')
) / 1_000_000
result['budget_usd'] = {
    'per_request': round(budget, 6),
    'per_month': {count: round(count * budget, 2) for count in costs['monthly_requests']},
}
assert result['eval']['qwen']['macro_f1'] == 0.610
assert result['eval']['rules']['macro_f1'] == 0.807
assert result['holdout']['qwen']['correct'] == 4
print(json.dumps(result, indent=2))
