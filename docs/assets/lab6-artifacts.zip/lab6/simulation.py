"""
6-ЗЖ. DentLux Portal: Монте-Карло симуляциясы арқылы жоба мерзімін болжау.
Google Colab-та тікелей іске қосуға болады (барлық кітапхана дайын).
"""
import json
from datetime import date, timedelta
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# ============ 1. ПАРАМЕТРЛЕР (тек осы жерді өзгертесіз) ============
CONFIG = {
    "history": [3, 4, 2, 5, 4, 3, 6, 2, 4, 5, 3, 4],  # апта сайынғы throughput
    "backlog": 30,               # бэклогтағы тарихша саны
    "n_sims": 10_000,            # симуляция саны
    "seed": 42,                  # нәтиже қайталануы үшін
    "start_date": date(2026, 10, 5),
    "percentiles": [50, 70, 85, 95],
    "commit_pct": 85,            # тапсырыс берушіге уәде ететін деңгей
    "target_weeks": 9,           # тексеретін мерзім: "9 аптада бітеміз бе?"
}
# ============ 2. ДЕРЕКТЕРДІ СИПАТТАУ ============
def describe_history(h):
    h = np.array(h)
    return {
        "weeks": len(h), "total": int(h.sum()), "mean": float(h.mean()),
        "median": float(np.median(h)), "std": float(h.std(ddof=1)),
        "min": int(h.min()), "max": int(h.max()),
        "cv": float(h.std(ddof=1) / h.mean()),   # вариация коэффициенті
    }
# ============ 3. СИМУЛЯЦИЯ ЯДРОСЫ ============
def simulate(history, backlog, n_sims, rng, zero_week_prob=0.0, max_weeks=200):
    """Әр жүгіртуде бэклог біткенше апта сайын тарихтан кездейсоқ мән алады.
    zero_week_prob - 'блокер аптасы' ықтималдығы (сол аптада throughput = 0)."""
    draws = rng.choice(history, size=(n_sims, max_weeks))
    if zero_week_prob > 0:
        draws = draws * (rng.random((n_sims, max_weeks)) >= zero_week_prob)
    cum = draws.cumsum(axis=1)
    reached = cum >= backlog
    if not reached.any(axis=1).all():
        raise ValueError("Simulation horizon exhausted; increase max_weeks")
    return reached.argmax(axis=1) + 1        # аяқталған апта нөмірі
def burndown_paths(history, backlog, n_sims, rng, horizon=14):
    draws = rng.choice(history, size=(n_sims, horizon))
    return np.maximum(backlog - draws.cumsum(axis=1), 0)
# ============ 4. ТАЛДАУ ФУНКЦИЯЛАРЫ ============
def percentile_table(weeks, pcts, start):
    rows = []
    for p in pcts:
        w = int(np.percentile(weeks, p, method="higher"))   # консервативті
        rows.append({"Перцентиль": f"P{p}", "Апта": w,
                     "Болжамды күн": (start + timedelta(weeks=w) - timedelta(days=1)).strftime("%d.%m.%Y")})
    return pd.DataFrame(rows)
def prob_within(weeks, k):
    """Жоба k аптада немесе ертерек біту ықтималдығы."""
    return float((weeks <= k).mean())
def run_scenarios(cfg, rng):
    h, b, n = cfg["history"], cfg["backlog"], cfg["n_sims"]
    scenarios = {
        "Базалық сценарий":              dict(history=h, backlog=b),
        "Скоуп +20% (36 тарихша)":       dict(history=h, backlog=int(b * 1.2)),
        "Скоуп -20% (24 тарихша)":       dict(history=h, backlog=int(b * 0.8)),
        "Throughput -1 (команда әлсіреді)": dict(history=[max(x - 1, 0) for x in h], backlog=b),
        "Соңғы 6 апта ғана":             dict(history=h[-6:], backlog=b),
        "Блокер тәуекелі (10% апта = 0)": dict(history=h, backlog=b, zero_week_prob=0.10),
    }
    out = []
    for name, kw in scenarios.items():
        w = simulate(kw["history"], kw["backlog"], n, rng, kw.get("zero_week_prob", 0.0))
        out.append({"Сценарий": name,
                    "P50": int(np.percentile(w, 50, method="higher")),
                    "P85": int(np.percentile(w, 85, method="higher")),
                    "P95": int(np.percentile(w, 95, method="higher")),
                    f"P(≤{cfg['target_weeks']} апта)": f"{prob_within(w, cfg['target_weeks']):.0%}"})
    return pd.DataFrame(out)
def bootstrap_p85(cfg, n_boot=300, sims=3000):
    """Тарихи деректер аз (12 апта), сондықтан P85-тің өзі қаншалық тұрақты?"""
    rng = np.random.default_rng(cfg["seed"] + 1)
    h = np.array(cfg["history"])
    vals = []
    for _ in range(n_boot):
        sample = rng.choice(h, size=len(h), replace=True)
        w = simulate(sample, cfg["backlog"], sims, rng)
        vals.append(np.percentile(w, cfg["commit_pct"], method="higher"))
    return np.percentile(vals, [5, 50, 95]), np.array(vals)
# ============ 5. ГРАФИКТЕР ============
try:
    get_ipython()            # Colab / Jupyter ішінде графиктер ұяшықтың астында шығады
    SHOW = True
except NameError:
    SHOW = False
def _show():
    if SHOW:
        plt.show()
    plt.close()
def plot_hist_cdf(weeks, pcts_w, n, backlog, path):
    fig, ax1 = plt.subplots(figsize=(9, 5.2))
    bins = range(weeks.min(), weeks.max() + 2)
    ax1.hist(weeks, bins=bins, density=True, alpha=0.6, color="skyblue", edgecolor="black")
    ax1.set_xlabel("Аяқталу уақыты (апта)"); ax1.set_ylabel("Жиілік (density)")
    ax2 = ax1.twinx()
    v, b = np.histogram(weeks, bins=bins)
    ax2.plot(b[:-1], np.cumsum(v) / n, color="red", lw=2, label="CDF")
    for p, c in zip((50, 85, 95), ("green", "orange", "purple")):
        ax2.axvline(pcts_w[p], color=c, ls="--", label=f"P{p}: {pcts_w[p]} апта")
    ax2.set_ylabel("Ықтималдық"); ax2.set_ylim(0, 1.05)
    plt.title(f"Бэклогты аяқтаудың Монте-Карло симуляциясы ({backlog} тарихша)")
    fig.tight_layout(); plt.legend(loc="lower right")
    plt.savefig(path, dpi=150); _show()
def plot_burndown(paths, backlog, path):
    x = np.arange(0, paths.shape[1] + 1)
    full = np.hstack([np.full((paths.shape[0], 1), backlog), paths])
    q = {p: np.percentile(full, p, axis=0) for p in (5, 15, 50, 85, 95)}
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.fill_between(x, q[5], q[95], color="lightblue", alpha=0.5, label="5–95% аралығы")
    ax.fill_between(x, q[15], q[85], color="steelblue", alpha=0.5, label="15–85% аралығы")
    ax.plot(x, q[50], color="navy", lw=2, label="Медиана")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_xlabel("Апта"); ax.set_ylabel("Қалған тарихша саны")
    ax.set_title("Бэклогтың жану болжамы (burn-down fan chart)")
    ax.legend(); fig.tight_layout(); plt.savefig(path, dpi=150); _show()
def plot_scenarios(df, path):
    fig, ax = plt.subplots(figsize=(9, 4.8))
    y = np.arange(len(df))
    ax.barh(y, df["P95"], color="plum", label="P95")
    ax.barh(y, df["P85"], color="orange", label="P85")
    ax.barh(y, df["P50"], color="seagreen", label="P50")
    ax.set_yticks(y); ax.set_yticklabels(df["Сценарий"]); ax.invert_yaxis()
    ax.set_xlabel("Апта"); ax.set_title("Сценарийлерді салыстыру")
    ax.legend(loc="lower right"); fig.tight_layout(); plt.savefig(path, dpi=150); _show()
# ============ 6. НЕГІЗГІ ІСКЕ ҚОСУ ============
def main(cfg=CONFIG, out_dir="."):
    rng = np.random.default_rng(cfg["seed"])
    h, b, n = cfg["history"], cfg["backlog"], cfg["n_sims"]
    stats = describe_history(h)
    det = b / stats["mean"]
    print("Throughput статистикасы:", stats)
    print(f"Детерминистік баға: {b}/{stats['mean']:.2f} = {det:.1f} апта\n")
    weeks = simulate(h, b, n, rng)
    table = percentile_table(weeks, cfg["percentiles"], cfg["start_date"])
    print(table.to_string(index=False))
    pw = {p: int(np.percentile(weeks, p, method="higher")) for p in (50, 70, 85, 95)}
    p_target = prob_within(weeks, cfg["target_weeks"])
    print(f"\nP(≤{cfg['target_weeks']} апта) = {p_target:.1%}")
    print("Апта бойынша ықтималдық:",
          {int(k): f"{(weeks <= k).mean():.0%}" for k in range(weeks.min(), weeks.max() + 1)})
    plot_hist_cdf(weeks, pw, n, b, f"{out_dir}/fig1_hist_cdf.png")
    plot_burndown(burndown_paths(h, b, n, rng), b, f"{out_dir}/fig2_burndown.png")
    sc = run_scenarios(cfg, rng)
    print("\n", sc.to_string(index=False))
    plot_scenarios(sc, f"{out_dir}/fig3_scenarios.png")
    ci, _ = bootstrap_p85(cfg)
    print(f"\nP85 bootstrap 90% аралығы: {ci[0]:.0f}–{ci[2]:.0f} апта (медиана {ci[1]:.0f})")
    table.to_csv(f"{out_dir}/percentiles.csv", index=False)
    sc.to_csv(f"{out_dir}/scenarios.csv", index=False)
    freq = {int(k): float((weeks == k).mean()) for k in range(weeks.min(), weeks.max() + 1)}
    json.dump({"stats": stats, "det": det, "table": table.to_dict("records"),
               "p_target": p_target, "scen": sc.to_dict("records"),
               "ci": ci.tolist(), "freq": freq, "pw": pw,
               "mean_sim": float(weeks.mean())},
              open(f"{out_dir}/results.json", "w"), ensure_ascii=False, indent=1)
if __name__ == "__main__":
    main()
